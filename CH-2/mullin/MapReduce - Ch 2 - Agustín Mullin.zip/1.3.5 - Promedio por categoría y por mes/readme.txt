# para compilar se requiere el archivo hadoop-core-1.0.4.jar del WordCount Example

# como compilar
javac -cp hadoop-core-1.0.4.jar *.java
jar cvf ComputePaymentsAvgPerMonthPerCateg.jar *.class

# como correrlo
# dejando el jar en el home de hadoop
# en la carpeta input del hdfs ubicar los archivos a procesar
bin/hadoop jar ComputePaymentsAvgPerMonthPerCateg.jar ComputePayments input output