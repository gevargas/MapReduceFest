import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.io.*;
import org.apache.hadoop.mapred.*;

public class ComputePaymentsReducer extends MapReduceBase 
	implements Reducer<TextPair, FloatWritable, TextPair, FloatWritable>
{
    //reduce method accepts the Key Value pairs from mappers, do the aggregation based on keys and produce the final out put
    public void reduce(TextPair key, Iterator<FloatWritable> values, 
    		OutputCollector<TextPair, FloatWritable> output, Reporter reporter) throws IOException
    {
        float sum = 0, cant=0;
        /*iterates through all the values available with a key and add them together and give the
         final result as the key and sum of its values*/
        while (values.hasNext())
        {
        	cant++;
            sum += values.next().get();
        }
        output.collect(key, new FloatWritable(sum/cant));
    }
}

