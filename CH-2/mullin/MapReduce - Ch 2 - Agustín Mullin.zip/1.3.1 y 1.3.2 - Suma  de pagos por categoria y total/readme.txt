# se entrega el punto 1.3.2 que resuelve tambi�n el 1.3.1

# para compilar se requiere el archivo hadoop-core-1.0.4.jar del WordCount Example

# como compilar
javac -cp hadoop-core-1.0.4.jar *.java
jar cvf ComputePaymentsWithTotal.jar *.class

# como correrlo
# dejando el jar en el home de hadoop
# en la carpeta input del hdfs ubicar los archivos a procesar
bin/hadoop jar ComputePaymentsWithTotal.jar ComputePayments input output