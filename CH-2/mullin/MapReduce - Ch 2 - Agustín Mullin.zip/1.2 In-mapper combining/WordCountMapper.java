import java.io.IOException;
import java.util.HashMap;
import java.util.StringTokenizer;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.hadoop.io.*;
import org.apache.hadoop.mapred.*;

public class WordCountMapper extends MapReduceBase 
	implements Mapper<LongWritable, Text, Text, IntWritable> 
{
	
	/** Local Cache for word counts */
	Map<Text, IntWritable> localCache;
 
	/** Temp store the the current word */
	Text word = new Text();
 
	/** donde escribir **/
	OutputCollector<Text, IntWritable> outputColl = null;
	
	@Override
//	protected void cleanup(Context context) throws IOException,
//			InterruptedException 
	public void close() throws IOException
	{
		// flush cache contents
		try {
			flushCache();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
 
	/**
	 * Flush the cache contents to the context
	 * 
	 * @param context
	 * @throws IOException
	 * @throws InterruptedException
	 */
	private void flushCache() throws IOException,
			InterruptedException {
		// output cache
		for (Entry<Text, IntWritable> entry : localCache.entrySet()) {
			//context.write(entry.getKey(), entry.getValue());
            outputColl.collect(entry.getKey(), entry.getValue());
		}
 
		// clear cache
		localCache.clear();
	}
 
	@Override
//	protected void setup(Context context) throws IOException,
//			InterruptedException 
	public void configure(JobConf job) 
	{
		localCache = new HashMap<Text, IntWritable>();
	}
 
	@Override
//	protected void map(LongWritable key, Text value, Context context)
//			throws IOException, InterruptedException 
    public void map(LongWritable key, Text value, OutputCollector<Text, IntWritable> output, 
    		Reporter reporter) throws IOException
	
    {
		// there are better ways of doing this, but for now we'll stick to the
		// WordCount example
		outputColl = output;
		
		StringTokenizer tokenizer = new StringTokenizer(value.toString());
		while (tokenizer.hasMoreTokens()) {
			word.set(tokenizer.nextToken());
			try {
				addWord();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
 
	/**
	 * Add word to the local cache count, flushing the cache if it reaches a
	 * pre-defined size
	 * 
	 * @param context
	 * @throws IOException
	 * @throws InterruptedException
	 */
	private void addWord() throws IOException,
			InterruptedException {
		// lookup current word count in local cache
		IntWritable count = localCache.get(word);
		if (count == null) {
			// if local cache size has reached threshold, then flush
			if (localCache.size() == 5000) {
				flushCache();
			}
 
			// no entry exists, so create a new count for word
			count = new IntWritable(0);
			// we need to create a copy of the word token as its contents will
			// be overwritten for the next token
			localCache.put(new Text(word), count);
		}
 
		// increment count - wouldn't it be nice if IntWritable had an
		// increment(int val) method..
		count.set(count.get() + 1);
	}

}
