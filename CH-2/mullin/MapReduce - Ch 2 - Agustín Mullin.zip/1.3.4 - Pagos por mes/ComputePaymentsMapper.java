import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.*;
import org.apache.hadoop.mapred.*;

public class ComputePaymentsMapper extends MapReduceBase 
	implements Mapper<LongWritable, Text, Text, FloatWritable>
{
    //hadoop supported data types
    private FloatWritable amount = new FloatWritable();
    private Text filename = new Text();

    public void configure(JobConf job){
    	filename.set(job.get("map.input.file"));
    }
    
    //map method that performs the tokenizer job and framing the initial key value pairs
    public void map(LongWritable key, Text value, 
    		OutputCollector<Text, FloatWritable> output, Reporter reporter) throws IOException
    {
        //taking one line at a time and tokenizing the same
        String line = value.toString();
        String[] valores = line.split(":");

        // la categoria
        // category.set(valores[0]);
        // el monto
        amount.set(Float.parseFloat(valores[3]));
        
        // devuelvo el monto por mes
        output.collect(filename, amount);


    }// end map
}