import java.io.*;

import org.apache.hadoop.io.*;

public class FloatPair implements WritableComparable<FloatPair> {

	private FloatWritable first;
	private FloatWritable second;
	
	public FloatPair() {
	
		set(new FloatWritable(), new FloatWritable());
	}
	
	public FloatPair(float first, float second) {
	
		set(new FloatWritable(first), new FloatWritable(second));
	}
	
	public FloatPair(FloatWritable first, FloatWritable second) {
	
		set(first, second);	
	}

	public void set(FloatWritable first, FloatWritable second) {
	
		this.first = first;
		this.second = second;	
	}

	public FloatWritable getFirst() {
	
		return first;
	}
	
	public FloatWritable getSecond() {
	
		return second;
	}

	@Override
	public void write(DataOutput out) throws IOException {
	
		first.write(out);
		second.write(out);
	}

	@Override
	public void readFields(DataInput in) throws IOException {
	
		first.readFields(in);
		second.readFields(in);
	}

	@Override
	public int hashCode() {
	
		return first.hashCode() * 163 + second.hashCode();
	}

	@Override
	public boolean equals(Object o) {
	
		if (o instanceof FloatPair) {
		
			FloatPair tp = (FloatPair) o;
			return first.equals(tp.first) && second.equals(tp.second);	
		}
		return false;
	}

	@Override
	public String toString() {
	
		return first + "\t" + second;
	}

	@Override
	public int compareTo(FloatPair tp) {
	
		int cmp = first.compareTo(tp.first);
	
		if (cmp != 0) {
	
			return cmp;
		}
	
		return second.compareTo(tp.second);
	}

}

