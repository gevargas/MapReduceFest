import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.io.*;
import org.apache.hadoop.mapred.*;

public class ComputePaymentsReducer extends MapReduceBase 
	implements Reducer<Text, FloatPair, Text, FloatWritable>
{
    //reduce method accepts the Key Value pairs from mappers, do the aggregation based on keys and produce the final out put
    public void reduce(Text key, Iterator<FloatPair> values, 
    		OutputCollector<Text, FloatWritable> output, Reporter reporter) throws IOException
    {
        float sum = 0, count=0;
        /*iterates through all the values available with a key and add them together and give the
         final result as the key and sum of its values*/
        FloatPair aux;
        while (values.hasNext())
        {
        	aux = values.next();
            sum += aux.getFirst().get();
            count += aux.getSecond().get();
        }
        float avg;
        if (count!=0)
        	avg = sum/count;
        else 
        	avg = -1;
        output.collect(key, new FloatWritable(avg));
    }
}

