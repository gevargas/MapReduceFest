import java.io.IOException;

import org.apache.hadoop.io.*;
import org.apache.hadoop.mapred.*;

public class ComputePaymentsMapper extends MapReduceBase 
	implements Mapper<LongWritable, Text, Text, FloatPair>
{
    //hadoop supported data types
    private FloatPair pareja = new FloatPair();
    private final static FloatWritable one = new FloatWritable(1f);
    private FloatWritable amount = new FloatWritable();
    
    private Text category = new Text();
    private final static Text total = new Text("TOTAL");
    
    //map method that performs the tokenizer job and framing the initial key value pairs
    public void map(LongWritable key, Text value, 
    		OutputCollector<Text, FloatPair> output, Reporter reporter) throws IOException
    {
        //taking one line at a time and tokenizing the same
        String line = value.toString();
        String[] valores = line.split(":");
        
        // la categoria
        category.set(valores[0]);
        // el monto y 1
        amount.set(Float.parseFloat(valores[3]));
        pareja.set(amount, one);
        
        // devuelvo el monto por categoria
        output.collect(category, pareja);
        
        // devuelvo el monto por total
        output.collect(total, pareja);

    }// end map
}