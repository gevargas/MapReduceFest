import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;


public class SumByCatMapper2 extends  Mapper<LongWritable, Text, Text, DoubleWritable>
{
    //hadoop supported data types
    Map<Text, Double> local;
    
    public void setup(Context context)throws IOException,
	InterruptedException {
		local = new HashMap<Text, Double>(); 
		local.put(new Text("Total"), new Double (0));
	}
	
    //map method that performs the tokenizer job and framing the initial key value pairs
    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException
    {
        //taking one line at a time and tokenizing the same
        String line = value.toString();
        String[] parsed =line.split(":");
        Text total = new Text("Total");
        
      //category is the key, amount is the value
        String category = parsed[0].replace("\"", "").trim();
        Text word= new Text(category);
        
        if (local.containsKey(word)) {
        	local.put(word, new Double (local.get(word) + Double.parseDouble(parsed[3])));
        }else{
        	local.put(word, new Double(parsed[3]));
        }
    	local.put(total, new Double (local.get(total) + Double.parseDouble(parsed[3])));
       
       // context.write(new Text(parsed[0]), new DoubleWritable(Double.parseDouble(parsed[3])));
    }
    
	public void cleanup(Context context) throws IOException, InterruptedException{
	    	
	    	Iterator<Entry<Text, Double>> it = local.entrySet().iterator();
	        while (it.hasNext()) {
	            Map.Entry pair = (Map.Entry)it.next();
	            context.write((Text)pair.getKey(), new DoubleWritable((Double)pair.getValue()));
	        }
	    }
    
}