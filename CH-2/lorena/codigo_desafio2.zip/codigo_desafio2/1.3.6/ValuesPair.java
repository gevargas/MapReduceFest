import java.io.*; 

import org.apache.hadoop.io.*;

public class ValuesPair implements Writable{
	
	private Integer quantity;
	private Double sum;
	
	public ValuesPair(){
		set(0,0);
	}
	
	public ValuesPair(Integer quantity, Double sum) {
		set(quantity, sum);
	}
	
	public void set(int quantity, double sum){
		this.quantity = new Integer(quantity);
		this.sum = new Double(sum);
	}
	

	public void readFields(DataInput arg0) throws IOException {
		this.quantity= arg0.readInt();
		this.sum = arg0.readDouble();
	}

	public void write(DataOutput arg0) throws IOException {
		arg0.write(this.quantity);
		arg0.writeDouble(this.sum);		
	}


	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getSum() {
		return sum;
	}

	public void setSum(double sum) {
		this.sum = sum;
	}

}
