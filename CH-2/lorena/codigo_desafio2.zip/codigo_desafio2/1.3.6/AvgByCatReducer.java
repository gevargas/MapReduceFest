import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Reducer;

public class AvgByCatReducer extends Reducer<Text, ValuesPair, Text, DoubleWritable>
{
    //reduce method accepts the Key Value pairs from mappers, do the aggregation based on keys and produce the final out put
    
	public void reduce(Text key, Iterable<ValuesPair> values, Context context) throws IOException, InterruptedException
    {
        double sum = 0;
        int cant = 0;
        for (ValuesPair value: values){
            sum += value.getSum();
            cant += value.getQuantity() ;
        }
        context.write(key, new DoubleWritable(sum/cant));
        
    }
}