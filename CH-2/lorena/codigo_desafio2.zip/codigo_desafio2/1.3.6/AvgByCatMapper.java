import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;


public class AvgByCatMapper extends  Mapper<LongWritable, Text, Text, ValuesPair>
{
	Map<Text, ValuesPair> local;
	
	public void setup(Context context)throws IOException,
	InterruptedException {
		local = new HashMap<Text, ValuesPair>(); 
	}
	
	
    //map method that performs the tokenizer job and framing the initial key value pairs
    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException
    {
        //taking one line at a time and tokenizing the same
        String line = value.toString();
        String[] parsed =line.split(":");
        
      //category is the key, amount is the value
        String category = parsed[0].replace("\"", "").trim();
        Text word= new Text(category);
        if (local.containsKey(word)) {
        	local.put(word, new ValuesPair(local.get(word).getQuantity()+1,local.get(word).getSum()+Double.parseDouble(parsed[3])));
        }else{
        	local.put(word, new ValuesPair(1,new Double(parsed[3])));
        }           
    }
    
    public void cleanup(Context context) throws IOException, InterruptedException{
    	
    	Iterator<Entry<Text, ValuesPair>> it = local.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry)it.next();
            context.write((Text)pair.getKey(), (ValuesPair)pair.getValue());
        }
    }
    
}