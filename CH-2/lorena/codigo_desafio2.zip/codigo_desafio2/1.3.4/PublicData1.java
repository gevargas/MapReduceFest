import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;


public class PublicData1 extends Configured implements Tool{
    public int run(String[] args) throws Exception
    {
        //creating a JobConf object and assigning a job name for identification purposes
        Job job = new Job();
        job.setJarByClass(PublicData1.class);
        job.setJobName("SumByCat");
        
        
        //Setting configuration object with the Data Type of output Key and Value
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(DoubleWritable.class);
        
        //Providing the mapper and reducer class names
 
        job.setMapperClass(SumByCatMapper.class);
        job.setReducerClass(SumByCatReducer.class);
        
        //the hdfs input and output directory to be fetched from the command line
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
        
        
        job.waitForCompletion(true);
        return 0;
    }
    
    public static void main(String[] args) throws Exception
    {
        int res = ToolRunner.run(new Configuration(), new PublicData1(),args);
        System.exit(res);
    }
}