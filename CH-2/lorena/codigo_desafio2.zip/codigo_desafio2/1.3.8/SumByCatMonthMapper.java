import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.io.FilenameUtils;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.mapreduce.lib.input.FileSplit; 


public class SumByCatMonthMapper extends  Mapper<Object, Text, CompoundKeyWritableComparable, DoubleWritable>
{
    //hadoop supported data types
    Map<CompoundKeyWritableComparable, Double> local;
    String month;
    
    public void setup(Context context)throws IOException,
	InterruptedException {
		local = new HashMap<CompoundKeyWritableComparable, Double>(); 
		String fileName = ((FileSplit) context.getInputSplit()).getPath().getName();
        month = FilenameUtils.removeExtension(fileName).split("_")[1];
	}
	
    //map method that performs the tokenizer job and framing the initial key value pairs
    public void map(Object key, Text value, Context context) throws IOException, InterruptedException
    {
        //taking one line at a time and tokenizing the same
        String line = value.toString();
        String[] parsed =line.split(":");
        
        String category = parsed[0].replace("\"", "").trim();
	    CompoundKeyWritableComparable k = new CompoundKeyWritableComparable(month,category);
        
      //(month,category) is the key, amount is the value
        if (local.containsKey(k)) {
        	local.put(k, new Double (local.get(k) + Double.parseDouble(parsed[3])));
        }else{
        	local.put(k, new Double(parsed[3]));
        }
    }
    
	public void cleanup(Context context) throws IOException, InterruptedException{
	    	
	    	Iterator<Entry<CompoundKeyWritableComparable, Double>> it = local.entrySet().iterator();
	        while (it.hasNext()) {
	            Map.Entry pair = (Map.Entry)it.next();
	            context.write((CompoundKeyWritableComparable)pair.getKey(), new DoubleWritable((Double)pair.getValue()));
	        }
	    }
    
}