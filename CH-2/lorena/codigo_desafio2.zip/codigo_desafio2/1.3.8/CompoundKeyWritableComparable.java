import java.io.*; 

import org.apache.hadoop.io.*;

public class CompoundKeyWritableComparable implements WritableComparable<CompoundKeyWritableComparable> {

	private String month;
	private String category;
	
	public CompoundKeyWritableComparable(){}
	
	
	public CompoundKeyWritableComparable(String month, String category) {
		this.month=month;
		this.category=category;
	}
	
	@Override
	public void readFields(DataInput arg0) throws IOException {
		this.month = Text.readString(arg0);
		this.category = Text.readString(arg0);
	}

	@Override
	public void write(DataOutput arg0) throws IOException {
		Text.writeString(arg0, this.month);
		Text.writeString(arg0, this.category);	
	}
	
	@Override
	  public int hashCode() {
	    return month.hashCode() * 163 + category.hashCode();
	  }
	  
	  @Override
	  public boolean equals(Object o) {
	    if (o instanceof CompoundKeyWritableComparable) {
	    	CompoundKeyWritableComparable tp = (CompoundKeyWritableComparable) o;
	      return month.equals(tp.month) && category.equals(tp.category);
	    }
	    return false;
	  }

	  @Override
	  public String toString() {
	    return month + "\t" + category;
	  }

	@Override
	public int compareTo(CompoundKeyWritableComparable o) {
		int cmp = month.compareTo(o.month); 
		if (cmp != 0) {
			return cmp; 
		}
		return category.compareTo(o.category);
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

}
